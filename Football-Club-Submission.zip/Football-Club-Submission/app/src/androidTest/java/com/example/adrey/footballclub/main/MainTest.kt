package com.example.adrey.footballclub.main

import android.support.test.espresso.Espresso
import android.support.test.espresso.Espresso.*
import android.support.test.espresso.UiController
import android.support.test.espresso.ViewAction
import android.support.test.espresso.action.ViewActions
import android.support.test.espresso.assertion.ViewAssertions.matches
import android.support.test.espresso.contrib.RecyclerViewActions
import android.support.test.espresso.matcher.ViewMatchers.*
import android.support.test.rule.ActivityTestRule
import android.support.test.runner.AndroidJUnit4
import android.support.v7.widget.RecyclerView
import com.example.adrey.footballclub.R.id.*
import org.hamcrest.Matchers.allOf
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import android.support.test.espresso.action.ViewActions.*
import com.example.adrey.footballclub.ui.home.HomeActivity


@RunWith(AndroidJUnit4::class)
class MainTest {

    @Rule
    @JvmField var matchRule = ActivityTestRule(HomeActivity::class.java)

    @Test
    fun test1() {
        onView(allOf(withId(listMatch), isDisplayed()))
                .perform(RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(10))
        onView(allOf(withId(listMatch), isDisplayed()))
                .perform(RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(10, click()))
        onView(withId(favorite))
                .check(matches(isDisplayed()))
        onView(withId(favorite))
                .perform(click())
        onView(withText("Added to favorite"))
                .check(matches(isDisplayed()))
    }

    @Test
    fun test2() {
        onView(withId(team)).check(matches(isDisplayed())).perform(click())
        onView(allOf(withId(rc_team), isDisplayed()))
                .perform(RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(0, click()))
        onView(withId(favorite))
                .check(matches(isDisplayed()))
        onView(withId(favorite))
                .perform(click())
        onView(withText("Added to favorite"))
                .check(matches(isDisplayed()))
    }

    @Test
    fun test3() {
        onView(withId(favorite)).check(matches(isDisplayed())).perform(click())
        onView(allOf(withId(listMatch), isDisplayed()))
                .perform(RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(0, click()))
        onView(withId(favorite))
                .check(matches(isDisplayed()))
        onView(withId(favorite))
                .perform(click())
        onView(withText("Removed to favorite"))
                .check(matches(isDisplayed()))
    }
}