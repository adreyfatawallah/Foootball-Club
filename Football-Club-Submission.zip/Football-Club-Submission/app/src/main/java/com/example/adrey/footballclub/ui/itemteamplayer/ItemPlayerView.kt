package com.example.adrey.footballclub.ui.itemteamplayer

import com.example.adrey.footballclub.model.player.Player

interface ItemPlayerView {

    fun showPlayer(player: List<Player>)
}